// supabase/functions/dispatch-notifications/index.ts
//
// Reads pending rows from `notification_log` (queued by the
// queue_alert_notifications() database trigger — see knosk_hr_schema.sql)
// and actually sends them, then marks each row sent/failed.
//
// This function is intentionally decoupled from the database logic that
// decides *whether* to notify someone: that decision is 100% reliable SQL
// with no external dependency. This function is the part that legitimately
// can fail (a provider outage, a bad API key, a rate limit) — so failures
// here update notification_log.status = 'failed' with an error message
// rather than blocking anything in the core HR app.
//
// Deploy:   supabase functions deploy dispatch-notifications
// Secrets:  supabase secrets set RESEND_API_KEY=... RESEND_FROM="KNOSK HR <hr@yourdomain.org>"
//           supabase secrets set TWILIO_ACCOUNT_SID=... TWILIO_AUTH_TOKEN=... TWILIO_WHATSAPP_FROM="whatsapp:+1415..."
// Schedule: wire this to run every few minutes via Supabase Cron
//           (Dashboard → Edge Functions → dispatch-notifications → Cron),
//           or call it manually while you're testing.

import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
const RESEND_FROM = Deno.env.get('RESEND_FROM') ?? 'KNOSK HR <onboarding@resend.dev>'
const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID')
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN')
const TWILIO_WHATSAPP_FROM = Deno.env.get('TWILIO_WHATSAPP_FROM')

interface NotificationRow {
  id: string
  alert_id: string
  channel: 'email' | 'whatsapp'
  recipient: string | null
  alerts: { message: string; severity: string } | null
}

async function sendEmail(to: string, message: string, severity: string): Promise<void> {
  if (!RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured')

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: RESEND_FROM,
      to: [to],
      subject: `KNOSK HR — ${severity.toUpperCase()} alert`,
      text: message,
    }),
  })

  if (!res.ok) {
    const body = await res.text()
    throw new Error(`Resend API error (${res.status}): ${body}`)
  }
}

async function sendWhatsApp(to: string, message: string): Promise<void> {
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_WHATSAPP_FROM) {
    throw new Error('Twilio WhatsApp credentials are not configured')
  }

  const url = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`
  const auth = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`)

  const body = new URLSearchParams({
    From: TWILIO_WHATSAPP_FROM,
    To: `whatsapp:${to}`,
    Body: message,
  })

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body,
  })

  if (!res.ok) {
    const body2 = await res.text()
    throw new Error(`Twilio API error (${res.status}): ${body2}`)
  }
}

Deno.serve(async (_req) => {
  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY)

  const { data: pending, error: fetchError } = await supabase
    .from('notification_log')
    .select('id, alert_id, channel, recipient, alerts:alert_id(message, severity)')
    .eq('status', 'pending')
    .limit(50)

  if (fetchError) {
    return new Response(JSON.stringify({ error: fetchError.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  const rows = (pending ?? []) as unknown as NotificationRow[]
  let sent = 0
  let failed = 0

  for (const row of rows) {
    if (!row.recipient) {
      await supabase
        .from('notification_log')
        .update({ status: 'failed', error_message: 'No recipient on file' })
        .eq('id', row.id)
      failed++
      continue
    }

    const message = row.alerts?.message ?? 'A KNOSK HR alert needs attention.'
    const severity = row.alerts?.severity ?? 'warning'

    try {
      if (row.channel === 'email') {
        await sendEmail(row.recipient, message, severity)
      } else {
        await sendWhatsApp(row.recipient, message)
      }
      await supabase
        .from('notification_log')
        .update({ status: 'sent', sent_at: new Date().toISOString() })
        .eq('id', row.id)
      sent++
    } catch (err) {
      await supabase
        .from('notification_log')
        .update({ status: 'failed', error_message: String(err) })
        .eq('id', row.id)
      failed++
    }
  }

  return new Response(JSON.stringify({ processed: rows.length, sent, failed }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  })
})
