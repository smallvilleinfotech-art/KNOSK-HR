import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { signIn } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    const { error } = await signIn(email, password)
    setSubmitting(false)
    if (error) setError(error.message)
  }

  return (
    <div className="min-h-screen bg-knosk-navy flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-knosk-gold flex items-center justify-center font-display font-extrabold text-knosk-navy text-2xl mb-3">
            K
          </div>
          <h1 className="font-display text-xl font-bold text-white">KNOSK HR System</h1>
          <p className="text-sm text-white/50 mt-1">Sign in to continue</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-card p-6 space-y-4">
          {error && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
              {error}
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-knosk-slate mb-1.5">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-knosk-line rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-knosk-blue focus:ring-2 focus:ring-knosk-blue-50"
              placeholder="you@knosk.org"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-knosk-slate mb-1.5">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-knosk-line rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-knosk-blue focus:ring-2 focus:ring-knosk-blue-50"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-knosk-blue text-white rounded-lg py-2.5 text-sm font-semibold hover:bg-knosk-blue/90 disabled:opacity-60 transition-colors"
          >
            {submitting ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="text-center text-xs text-white/40 mt-6">
          Accounts are created by an HR admin in Supabase — there's no public sign-up.
        </p>
      </div>
    </div>
  )
}
