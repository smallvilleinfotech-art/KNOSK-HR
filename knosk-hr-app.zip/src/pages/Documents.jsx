import { useEffect, useRef, useState } from 'react'
import { Upload, ExternalLink, Loader2 } from 'lucide-react'
import { Card } from '../components/Card'
import { useAuth } from '../context/AuthContext'
import { fetchStaffDocumentsInventory, updateStaffDocumentStatus, updateStaffDocumentFile } from '../lib/queries'
import { uploadStaffDocument, getSignedDocumentUrl } from '../lib/storage'

const STATUS_OPTIONS = ['missing', 'draft', 'pending_signature', 'signed', 'filed', 'expired']
const STATUS_STYLE = {
  missing: 'bg-red-50 text-red-600',
  draft: 'bg-gray-100 text-gray-500',
  pending_signature: 'bg-knosk-gold-50 text-knosk-gold',
  signed: 'bg-knosk-blue-50 text-knosk-blue',
  filed: 'bg-emerald-50 text-emerald-700',
  expired: 'bg-red-50 text-red-600',
}

function UploadCell({ row, onUploaded }) {
  const { profile } = useAuth()
  const inputRef = useRef(null)
  const [busy, setBusy] = useState(false)
  const [opening, setOpening] = useState(false)
  const [error, setError] = useState(null)

  async function handleFile(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setBusy(true)
    setError(null)
    const { path, error: uploadError } = await uploadStaffDocument(row.staff_id, row.document_type_id, file)
    if (uploadError) {
      setBusy(false)
      setError(uploadError.message)
      return
    }
    const { error: dbError } = await updateStaffDocumentFile(row.id, path, profile?.id)
    setBusy(false)
    if (dbError) {
      setError(dbError.message)
      return
    }
    onUploaded(row.id, path)
  }

  async function handleView() {
    if (!row.file_url) return
    setOpening(true)
    const { data, error } = await getSignedDocumentUrl(row.file_url)
    setOpening(false)
    if (error) {
      setError(error.message)
      return
    }
    window.open(data.signedUrl, '_blank', 'noopener')
  }

  return (
    <div className="flex items-center gap-2">
      {row.file_url && (
        <button
          onClick={handleView}
          disabled={opening}
          className="flex items-center gap-1 text-xs font-semibold text-knosk-blue hover:underline"
        >
          {opening ? <Loader2 size={12} className="animate-spin" /> : <ExternalLink size={12} />} View
        </button>
      )}
      <button
        onClick={() => inputRef.current?.click()}
        disabled={busy}
        className="flex items-center gap-1 text-xs font-semibold text-knosk-slate hover:text-knosk-blue disabled:opacity-60"
      >
        {busy ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />}
        {row.file_url ? 'Replace' : 'Upload'}
      </button>
      <input ref={inputRef} type="file" className="hidden" onChange={handleFile} />
      {error && <span className="text-xs text-red-600">{error}</span>}
    </div>
  )
}

export default function Documents() {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [filter, setFilter] = useState('')

  function load() {
    setLoading(true)
    fetchStaffDocumentsInventory({ statusFilter: filter || undefined }).then(({ data, error }) => {
      setRows(data ?? [])
      setError(error)
      setLoading(false)
    })
  }
  useEffect(load, [filter])

  async function handleStatusChange(id, status) {
    setRows((r) => r.map((row) => (row.id === id ? { ...row, status } : row)))
    await updateStaffDocumentStatus(id, status)
  }

  function handleUploaded(id, path) {
    setRows((r) => r.map((row) => (row.id === id ? { ...row, file_url: path } : row)))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-knosk-slate">
          What exists per staff member, and what's still missing before a file is complete.
        </p>
        <div className="flex gap-2 flex-wrap">
          {['', ...STATUS_OPTIONS].map((s) => (
            <button
              key={s || 'all'}
              onClick={() => setFilter(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
                filter === s ? 'bg-knosk-navy text-white border-knosk-navy' : 'bg-white text-knosk-slate border-knosk-line hover:border-knosk-blue'
              }`}
            >
              {s === '' ? 'All' : s.replaceAll('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">
          Couldn't load documents — {error.message}
        </Card>
      )}

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-knosk-slate border-b border-knosk-line">
              <th className="px-5 py-3 font-medium">Staff</th>
              <th className="px-5 py-3 font-medium">Document</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium">File</th>
              <th className="px-5 py-3 font-medium">Expiry</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="px-5 py-8 text-center text-knosk-slate">Loading…</td></tr>}
            {!loading && rows.length === 0 && !error && (
              <tr><td colSpan={5} className="px-5 py-8 text-center text-knosk-slate">No documents match this filter.</td></tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-knosk-line last:border-0">
                <td className="px-5 py-3 font-medium text-knosk-ink">{r.staff?.full_name}</td>
                <td className="px-5 py-3 text-knosk-slate">{r.document_type?.name}</td>
                <td className="px-5 py-3">
                  <select
                    value={r.status}
                    onChange={(e) => handleStatusChange(r.id, e.target.value)}
                    className={`text-xs font-semibold px-2 py-1 rounded-full border-0 outline-none cursor-pointer ${STATUS_STYLE[r.status]}`}
                  >
                    {STATUS_OPTIONS.map((s) => (
                      <option key={s} value={s}>{s.replaceAll('_', ' ')}</option>
                    ))}
                  </select>
                </td>
                <td className="px-5 py-3">
                  <UploadCell row={r} onUploaded={handleUploaded} />
                </td>
                <td className="px-5 py-3 text-knosk-slate">{r.expiry_date ? new Date(r.expiry_date).toLocaleDateString() : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
