import { useEffect, useState } from 'react'
import { ChevronDown, ChevronRight, Check } from 'lucide-react'
import { Card } from '../components/Card'
import { useAuth } from '../context/AuthContext'
import { fetchOnboardingStaff, fetchOnboardingTasksForStaff, updateOnboardingTask } from '../lib/queries'

function TaskChecklist({ staffId, onChange }) {
  const { profile } = useAuth()
  const [tasks, setTasks] = useState(null)

  function load() {
    fetchOnboardingTasksForStaff(staffId).then(({ data }) => setTasks(data ?? []))
  }
  useEffect(load, [staffId])

  async function toggle(task) {
    const nextStatus = task.status === 'completed' ? 'pending' : 'completed'
    await updateOnboardingTask(task.id, { status: nextStatus, completedBy: profile?.id })
    load()
    onChange?.()
  }

  if (!tasks) return <p className="text-sm text-knosk-slate px-4 py-3">Loading tasks…</p>
  if (tasks.length === 0) return <p className="text-sm text-knosk-slate px-4 py-3">No onboarding tasks generated yet.</p>

  return (
    <ul className="divide-y divide-knosk-line px-1">
      {tasks.map((t) => (
        <li key={t.id} className="flex items-center gap-3 px-4 py-2.5">
          <button
            onClick={() => toggle(t)}
            className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
              t.status === 'completed' ? 'bg-knosk-blue border-knosk-blue text-white' : 'border-knosk-line'
            }`}
          >
            {t.status === 'completed' && <Check size={13} />}
          </button>
          <span className={`text-sm flex-1 ${t.status === 'completed' ? 'text-knosk-slate line-through' : 'text-knosk-ink'}`}>
            {t.task_name}
          </span>
          {t.due_date && <span className="text-xs text-knosk-slate">due {new Date(t.due_date).toLocaleDateString()}</span>}
        </li>
      ))}
    </ul>
  )
}

export default function Onboarding() {
  const [staff, setStaff] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [expanded, setExpanded] = useState(null)

  useEffect(() => {
    fetchOnboardingStaff().then(({ data, error }) => {
      setStaff(data ?? [])
      setError(error)
      setLoading(false)
    })
  }, [])

  return (
    <div className="space-y-4">
      <p className="text-sm text-knosk-slate">
        Everyone currently on probation, with their onboarding checklist. Templates are role/track-specific,
        generated automatically from the SOP when a staff record is created.
      </p>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">
          Couldn't load onboarding staff — {error.message}
        </Card>
      )}
      {loading && <p className="text-sm text-knosk-slate">Loading…</p>}
      {!loading && staff.length === 0 && !error && (
        <Card className="p-6 text-sm text-knosk-slate">No one is currently on probation/onboarding.</Card>
      )}

      <div className="space-y-3">
        {staff.map((s) => (
          <Card key={s.id} className="overflow-hidden">
            <button
              className="w-full flex items-center justify-between px-5 py-4 text-left"
              onClick={() => setExpanded(expanded === s.id ? null : s.id)}
            >
              <div className="flex items-center gap-3">
                {expanded === s.id ? <ChevronDown size={16} className="text-knosk-slate" /> : <ChevronRight size={16} className="text-knosk-slate" />}
                <div>
                  <p className="font-medium text-knosk-ink">{s.full_name}</p>
                  <p className="text-xs text-knosk-slate">{s.job_title} · {s.track === 'ngo' ? 'NGO' : 'Academic'}</p>
                </div>
              </div>
              <span className="text-xs text-knosk-slate">
                Started {s.start_date ? new Date(s.start_date).toLocaleDateString() : '—'}
              </span>
            </button>
            {expanded === s.id && (
              <div className="border-t border-knosk-line">
                <TaskChecklist staffId={s.id} />
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  )
}
