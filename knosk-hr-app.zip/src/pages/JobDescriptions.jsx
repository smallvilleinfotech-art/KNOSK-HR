import { useEffect, useState } from 'react'
import { Plus, CheckCircle2, CircleDashed } from 'lucide-react'
import { Card } from '../components/Card'
import Modal from '../components/Modal'
import { Field, inputCls, buttonPrimary, buttonGhost } from '../components/FormField'
import { useAuth } from '../context/AuthContext'
import {
  fetchJobDescriptions,
  createJobDescription,
  updateJobDescription,
  fetchOrgNodesForSelect,
} from '../lib/queries'

const emptyForm = {
  title: '',
  track: 'ngo',
  org_node_id: '',
  reports_to_node_id: '',
  role_summary: '',
  kpis: [{ metric: '', target: '' }],
  is_approved: false,
}

export default function JobDescriptions() {
  const { profile } = useAuth()
  const [jds, setJds] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [orgNodes, setOrgNodes] = useState([])
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState(null)

  function load() {
    setLoading(true)
    fetchJobDescriptions().then(({ data, error }) => {
      setJds(data ?? [])
      setError(error)
      setLoading(false)
    })
  }

  useEffect(load, [])

  useEffect(() => {
    fetchOrgNodesForSelect(form.track).then(({ data }) => setOrgNodes(data ?? []))
  }, [form.track])

  function openCreate() {
    setEditingId(null)
    setForm(emptyForm)
    setSaveError(null)
    setModalOpen(true)
  }

  function openEdit(jd) {
    setEditingId(jd.id)
    setForm({
      title: jd.title,
      track: jd.track,
      org_node_id: jd.org_node_id ?? '',
      reports_to_node_id: jd.reports_to_node_id ?? '',
      role_summary: jd.role_summary ?? '',
      kpis: jd.kpis?.length ? jd.kpis : [{ metric: '', target: '' }],
      is_approved: jd.is_approved,
    })
    setSaveError(null)
    setModalOpen(true)
  }

  function updateKpi(idx, key, value) {
    setForm((f) => {
      const kpis = [...f.kpis]
      kpis[idx] = { ...kpis[idx], [key]: value }
      return { ...f, kpis }
    })
  }

  function addKpi() {
    setForm((f) => ({ ...f, kpis: [...f.kpis, { metric: '', target: '' }] }))
  }

  function removeKpi(idx) {
    setForm((f) => ({ ...f, kpis: f.kpis.filter((_, i) => i !== idx) }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setSaveError(null)

    const payload = {
      title: form.title.trim(),
      track: form.track,
      org_node_id: form.org_node_id || null,
      reports_to_node_id: form.reports_to_node_id || null,
      role_summary: form.role_summary.trim(),
      kpis: form.kpis.filter((k) => k.metric.trim()),
      is_approved: form.is_approved,
      ...(form.is_approved ? { approved_by: profile?.id, approved_at: new Date().toISOString() } : {}),
    }

    const { error } = editingId
      ? await updateJobDescription(editingId, payload)
      : await createJobDescription(payload)

    setSaving(false)
    if (error) {
      setSaveError(error.message)
      return
    }
    setModalOpen(false)
    load()
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <p className="text-sm text-knosk-slate">
          Every offer letter must be built from an approved JD — this is the source of truth.
        </p>
        <button onClick={openCreate} className={`${buttonPrimary} flex items-center gap-1.5`}>
          <Plus size={16} /> New JD
        </button>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">
          Couldn't load job descriptions — {error.message}
        </Card>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {loading && <p className="text-sm text-knosk-slate">Loading…</p>}
        {!loading && jds.length === 0 && !error && (
          <p className="text-sm text-knosk-slate">No job descriptions yet — add the first one.</p>
        )}
        {jds.map((jd) => (
          <Card key={jd.id} className="p-5 cursor-pointer hover:border-knosk-blue transition-colors" >
            <div className="flex items-start justify-between gap-3" onClick={() => openEdit(jd)}>
              <div className="min-w-0">
                <h3 className="font-display font-bold text-knosk-navy truncate">{jd.title}</h3>
                <p className="text-xs text-knosk-slate mt-0.5">
                  {jd.org_node?.title || 'Unassigned dept'} · reports to {jd.reports_to?.title || '—'}
                </p>
              </div>
              <span
                className={`shrink-0 flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full ${
                  jd.is_approved ? 'bg-emerald-50 text-emerald-700' : 'bg-knosk-gold-50 text-knosk-gold'
                }`}
              >
                {jd.is_approved ? <CheckCircle2 size={13} /> : <CircleDashed size={13} />}
                {jd.is_approved ? 'Approved' : 'Draft'}
              </span>
            </div>
            <p className="text-sm text-knosk-slate mt-3 line-clamp-2">{jd.role_summary}</p>
            {jd.kpis?.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-3">
                {jd.kpis.slice(0, 3).map((k, i) => (
                  <span key={i} className="text-xs bg-knosk-blue-50 text-knosk-blue px-2 py-1 rounded-full">
                    {k.metric}: {k.target}
                  </span>
                ))}
              </div>
            )}
          </Card>
        ))}
      </div>

      {modalOpen && (
        <Modal title={editingId ? 'Edit job description' : 'New job description'} onClose={() => setModalOpen(false)} wide>
          <form onSubmit={handleSubmit} className="space-y-4">
            {saveError && (
              <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{saveError}</div>
            )}
            <Field label="Job title (exact — this is what offer letters must copy)">
              <input required className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </Field>

            <div className="grid grid-cols-2 gap-4">
              <Field label="Track">
                <select
                  className={inputCls}
                  value={form.track}
                  onChange={(e) => setForm({ ...form, track: e.target.value, org_node_id: '', reports_to_node_id: '' })}
                >
                  <option value="ngo">NGO</option>
                  <option value="academic">Academic</option>
                </select>
              </Field>
              <Field label="Department / seat">
                <select className={inputCls} value={form.org_node_id} onChange={(e) => setForm({ ...form, org_node_id: e.target.value })}>
                  <option value="">— select —</option>
                  {orgNodes.map((n) => (
                    <option key={n.id} value={n.id}>{n.title}</option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label="Reports to">
              <select className={inputCls} value={form.reports_to_node_id} onChange={(e) => setForm({ ...form, reports_to_node_id: e.target.value })}>
                <option value="">— select —</option>
                {orgNodes.map((n) => (
                  <option key={n.id} value={n.id}>{n.title}</option>
                ))}
              </select>
            </Field>

            <Field label="Role summary (pasted into offer letters verbatim)">
              <textarea
                required
                rows={4}
                className={inputCls}
                value={form.role_summary}
                onChange={(e) => setForm({ ...form, role_summary: e.target.value })}
              />
            </Field>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-knosk-slate">Named KPIs</label>
                <button type="button" onClick={addKpi} className="text-xs text-knosk-blue font-semibold">+ Add KPI</button>
              </div>
              <div className="space-y-2">
                {form.kpis.map((k, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      placeholder="Metric (e.g. videos produced)"
                      className={inputCls}
                      value={k.metric}
                      onChange={(e) => updateKpi(idx, 'metric', e.target.value)}
                    />
                    <input
                      placeholder="Target (e.g. 2/month)"
                      className={inputCls}
                      value={k.target}
                      onChange={(e) => updateKpi(idx, 'target', e.target.value)}
                    />
                    {form.kpis.length > 1 && (
                      <button type="button" onClick={() => removeKpi(idx)} className="text-xs text-red-500 px-2">✕</button>
                    )}
                  </div>
                ))}
              </div>
              <p className="text-xs text-knosk-slate mt-2">
                No quantified KPI yet? Leave blank — the offer letter will state performance measures
                will follow the Performance Management Framework. Don't invent a number.
              </p>
            </div>

            <label className="flex items-center gap-2 text-sm text-knosk-ink">
              <input
                type="checkbox"
                checked={form.is_approved}
                onChange={(e) => setForm({ ...form, is_approved: e.target.checked })}
              />
              Mark as approved (required before it can back an offer letter)
            </label>

            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className={buttonGhost}>Cancel</button>
              <button type="submit" disabled={saving} className={buttonPrimary}>
                {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create JD'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
