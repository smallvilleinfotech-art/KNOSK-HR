import { useEffect, useMemo, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { RotateCcw, Info } from 'lucide-react'
import { Card } from '../components/Card'
import { fetchOrgTree } from '../lib/queries'
import { buildTree } from '../lib/treeLayout'
import OrgNode3D from '../components/orgchart3d/OrgNode3D'
import Edge3D from '../components/orgchart3d/Edge3D'
import CameraRig from '../components/orgchart3d/CameraRig'

function Scene({ flat, edges, selectedId, relatedIds, onSelect, focusPoint }) {
  return (
    <Canvas camera={{ position: [0, 1.5, 9], fov: 45 }}>
      <color attach="background" args={['#fafaf8']} />
      <ambientLight intensity={0.9} />
      <directionalLight position={[5, 8, 5]} intensity={0.6} />

      {edges.map(([a, b], i) => (
        <Edge3D
          key={i}
          from={a}
          to={b}
          isDimmed={selectedId ? !(relatedIds.has(a.id) && relatedIds.has(b.id)) : false}
        />
      ))}

      {flat.map((node) => (
        <OrgNode3D
          key={node.id}
          node={node}
          isSelected={node.id === selectedId}
          isDimmed={selectedId ? !relatedIds.has(node.id) : false}
          onSelect={onSelect}
        />
      ))}

      <CameraRig focusPoint={focusPoint} />
    </Canvas>
  )
}

export default function OrgChart3D() {
  const [track, setTrack] = useState('ngo')
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selectedId, setSelectedId] = useState(null)

  useEffect(() => {
    setLoading(true)
    setSelectedId(null)
    fetchOrgTree(track).then(({ data, error }) => {
      setRows(data ?? [])
      setError(error)
      setLoading(false)
    })
  }, [track])

  const { flat, byId, edges } = useMemo(() => {
    if (rows.length === 0) return { flat: [], byId: new Map(), edges: [] }
    const tree = buildTree(rows)
    const edgeList = []
    tree.flat.forEach((n) => {
      if (n.parent_id && tree.byId.has(n.parent_id)) {
        edgeList.push([tree.byId.get(n.parent_id), n])
      }
    })
    return { flat: tree.flat, byId: tree.byId, edges: edgeList }
  }, [rows])

  const selectedNode = selectedId ? byId.get(selectedId) : null

  // "related" = selected node + its direct children + its parent, so clicking
  // a node visually surfaces its sub-items while the rest of the tree dims.
  const relatedIds = useMemo(() => {
    const set = new Set()
    if (!selectedNode) return set
    set.add(selectedNode.id)
    if (selectedNode.parent_id) set.add(selectedNode.parent_id)
    selectedNode.children?.forEach((c) => set.add(c.id))
    return set
  }, [selectedNode])

  const focusPoint = selectedNode ?? { x: 0, y: -1.5, z: 0 }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-knosk-slate max-w-xl">
          Drag to rotate, scroll to zoom, right-drag to pan. Click any node to focus it and reveal its
          direct reports; everything else dims so the sub-tree is easy to read.
        </p>
        <div className="flex gap-2">
          {['ngo', 'academic'].map((t) => (
            <button
              key={t}
              onClick={() => setTrack(t)}
              className={`px-3.5 py-2 rounded-full text-xs font-semibold border transition-colors ${
                track === t ? 'bg-knosk-navy text-white border-knosk-navy' : 'bg-white text-knosk-slate border-knosk-line hover:border-knosk-blue'
              }`}
            >
              {t === 'ngo' ? 'NGO' : 'School'}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">Couldn't load the org chart — {error.message}</Card>
      )}

      <div className="grid lg:grid-cols-4 gap-4">
        <Card className="lg:col-span-3 overflow-hidden h-[560px] relative">
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center text-sm text-knosk-slate bg-knosk-cream/60 z-10">
              Loading org chart…
            </div>
          )}
          {!loading && flat.length > 0 && (
            <Scene
              flat={flat}
              edges={edges}
              selectedId={selectedId}
              relatedIds={relatedIds}
              onSelect={(n) => setSelectedId(n.id === selectedId ? null : n.id)}
              focusPoint={focusPoint}
            />
          )}
          {!loading && flat.length === 0 && !error && (
            <div className="absolute inset-0 flex items-center justify-center text-sm text-knosk-slate">
              No org chart nodes found for this track.
            </div>
          )}

          {selectedId && (
            <button
              onClick={() => setSelectedId(null)}
              className="absolute top-3 right-3 flex items-center gap-1.5 text-xs font-semibold bg-white border border-knosk-line rounded-full px-3 py-1.5 hover:border-knosk-blue"
            >
              <RotateCcw size={13} /> Reset view
            </button>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="font-display font-bold text-knosk-navy mb-3 flex items-center gap-1.5">
            <Info size={15} /> Node detail
          </h3>
          {!selectedNode && <p className="text-sm text-knosk-slate">Click any node to see its detail here.</p>}
          {selectedNode && (
            <div className="space-y-3">
              <div>
                <p className="font-semibold text-knosk-ink">{selectedNode.title}</p>
                {selectedNode.subtitle && <p className="text-xs text-knosk-slate mt-0.5">{selectedNode.subtitle}</p>}
              </div>
              {selectedNode.current_holder && (
                <div className="text-sm">
                  <span className="text-knosk-slate">Held by </span>
                  <span className="font-medium text-knosk-ink">{selectedNode.current_holder}</span>
                </div>
              )}
              <div>
                <p className="text-xs text-knosk-slate mb-1.5">
                  Direct reports ({selectedNode.children?.length ?? 0})
                </p>
                {selectedNode.children?.length ? (
                  <ul className="space-y-1">
                    {selectedNode.children.map((c) => (
                      <li key={c.id}>
                        <button
                          onClick={() => setSelectedId(c.id)}
                          className="text-sm text-knosk-blue hover:underline text-left"
                        >
                          {c.title}
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-knosk-slate">No sub-items.</p>
                )}
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
