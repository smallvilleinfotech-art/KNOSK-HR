import { useEffect, useState } from 'react'
import { ChevronDown, ChevronRight, Check, ShieldAlert, DoorOpen } from 'lucide-react'
import { Card } from '../components/Card'
import { buttonPrimary } from '../components/FormField'
import { useAuth } from '../context/AuthContext'
import {
  fetchOffboardingStaff,
  fetchOffboardingTasksForStaff,
  updateOffboardingTask,
  finalizeExit,
} from '../lib/queries'

function TaskChecklist({ staffId, onChange }) {
  const { profile } = useAuth()
  const [tasks, setTasks] = useState(null)

  function load() {
    fetchOffboardingTasksForStaff(staffId).then(({ data }) => setTasks(data ?? []))
  }
  useEffect(load, [staffId])

  async function toggle(task) {
    const nextStatus = task.status === 'completed' ? 'pending' : 'completed'
    await updateOffboardingTask(task.id, { status: nextStatus, completedBy: profile?.id })
    load()
    onChange?.()
  }

  if (!tasks) return <p className="text-sm text-knosk-slate px-4 py-3">Loading tasks…</p>
  if (tasks.length === 0) return <p className="text-sm text-knosk-slate px-4 py-3">No offboarding tasks generated yet.</p>

  return (
    <ul className="divide-y divide-knosk-line px-1">
      {tasks.map((t) => (
        <li key={t.id} className="flex items-center gap-3 px-4 py-2.5">
          <button
            onClick={() => toggle(t)}
            className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
              t.status === 'completed' ? 'bg-knosk-blue border-knosk-blue text-white' : 'border-knosk-line'
            }`}
          >
            {t.status === 'completed' && <Check size={13} />}
          </button>
          <span className={`text-sm flex-1 ${t.status === 'completed' ? 'text-knosk-slate line-through' : 'text-knosk-ink'}`}>
            {t.task_name}
          </span>
          {t.is_mandatory && (
            <span className="text-[10px] font-semibold uppercase tracking-wide text-knosk-gold bg-knosk-gold-50 px-1.5 py-0.5 rounded">
              mandatory
            </span>
          )}
        </li>
      ))}
    </ul>
  )
}

function ExitRow({ s, onFinalized }) {
  const [expanded, setExpanded] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)
  const [tasks, setTasks] = useState(null)
  const [finalizing, setFinalizing] = useState(false)
  const [blockError, setBlockError] = useState(null)

  useEffect(() => {
    fetchOffboardingTasksForStaff(s.id).then(({ data }) => setTasks(data ?? []))
  }, [s.id, refreshKey])

  const mandatoryOpen = (tasks ?? []).filter((t) => t.is_mandatory && t.status !== 'completed').length
  const clearedToExit = tasks !== null && mandatoryOpen === 0

  async function handleFinalize() {
    setFinalizing(true)
    setBlockError(null)
    const { error } = await finalizeExit(s.id, 'resigned')
    setFinalizing(false)
    if (error) {
      setBlockError(error.message)
      return
    }
    onFinalized?.()
  }

  return (
    <Card className="overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-5 py-4 text-left"
        onClick={() => setExpanded((v) => !v)}
      >
        <div className="flex items-center gap-3">
          {expanded ? <ChevronDown size={16} className="text-knosk-slate" /> : <ChevronRight size={16} className="text-knosk-slate" />}
          <div>
            <p className="font-medium text-knosk-ink">{s.full_name}</p>
            <p className="text-xs text-knosk-slate">{s.job_title} · {s.track === 'ngo' ? 'NGO' : 'Academic'}</p>
          </div>
        </div>
        <span
          className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${
            clearedToExit ? 'bg-emerald-50 text-emerald-700' : 'bg-orange-50 text-orange-700'
          }`}
        >
          {clearedToExit ? <Check size={13} /> : <ShieldAlert size={13} />}
          {tasks === null ? '…' : clearedToExit ? 'Cleared to exit' : `${mandatoryOpen} mandatory task(s) open`}
        </span>
      </button>

      {expanded && (
        <div className="border-t border-knosk-line">
          <TaskChecklist staffId={s.id} onChange={() => setRefreshKey((k) => k + 1)} />
          <div className="px-5 py-4 border-t border-knosk-line flex items-center justify-between gap-3">
            {blockError && <p className="text-xs text-red-600 flex-1">{blockError}</p>}
            <button
              onClick={handleFinalize}
              disabled={!clearedToExit || finalizing}
              className={`${buttonPrimary} flex items-center gap-1.5 ml-auto`}
              title={!clearedToExit ? 'Complete mandatory tasks first — the database will reject this otherwise' : ''}
            >
              <DoorOpen size={15} />
              {finalizing ? 'Finalizing…' : 'Finalize exit'}
            </button>
          </div>
        </div>
      )}
    </Card>
  )
}

export default function Offboarding() {
  const [staff, setStaff] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  function load() {
    setLoading(true)
    fetchOffboardingStaff().then(({ data, error }) => {
      setStaff(data ?? [])
      setError(error)
      setLoading(false)
    })
  }
  useEffect(load, [])

  return (
    <div className="space-y-4">
      <p className="text-sm text-knosk-slate">
        No one exits without a completed structured handover — the database itself blocks the status
        change while a mandatory task is open, this UI just makes that visible before you hit the wall.
      </p>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">
          Couldn't load offboarding staff — {error.message}
        </Card>
      )}
      {loading && <p className="text-sm text-knosk-slate">Loading…</p>}
      {!loading && staff.length === 0 && !error && (
        <Card className="p-6 text-sm text-knosk-slate">No one is currently offboarding.</Card>
      )}

      <div className="space-y-3">
        {staff.map((s) => (
          <ExitRow key={s.id} s={s} onFinalized={load} />
        ))}
      </div>
    </div>
  )
}
