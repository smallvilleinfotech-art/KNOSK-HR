import { useEffect, useState } from 'react'
import { Plus, Check, AlertCircle } from 'lucide-react'
import { Card } from '../components/Card'
import Modal from '../components/Modal'
import { Field, inputCls, buttonPrimary, buttonGhost } from '../components/FormField'
import { useAuth } from '../context/AuthContext'
import {
  fetchReassignments,
  createReassignment,
  updateReassignmentHandover,
  fetchAllStaffForSelect,
  fetchOrgNodesForSelect,
} from '../lib/queries'

const emptyForm = { staffId: '', toOrgNodeId: '', effectiveDate: '', reason: '' }

export default function Reassignments() {
  const { profile } = useAuth()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [staffOptions, setStaffOptions] = useState([])
  const [orgNodeOptions, setOrgNodeOptions] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState(null)

  function load() {
    setLoading(true)
    fetchReassignments().then(({ data, error }) => {
      setRows(data ?? [])
      setError(error)
      setLoading(false)
    })
  }
  useEffect(load, [])

  async function openModal() {
    const [{ data: staffData }, ngoNodes, academicNodes] = await Promise.all([
      fetchAllStaffForSelect(),
      fetchOrgNodesForSelect('ngo'),
      fetchOrgNodesForSelect('academic'),
    ])
    setStaffOptions(staffData ?? [])
    setOrgNodeOptions([...(ngoNodes.data ?? []), ...(academicNodes.data ?? [])])
    setForm(emptyForm)
    setSaveError(null)
    setModalOpen(true)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setSaveError(null)
    const { error } = await createReassignment({
      staff_id: form.staffId,
      to_org_node_id: form.toOrgNodeId,
      effective_date: form.effectiveDate,
      reason: form.reason.trim() || null,
      approved_by: profile?.id,
    })
    setSaving(false)
    if (error) {
      setSaveError(error.message)
      return
    }
    setModalOpen(false)
    load()
  }

  async function toggleHandover(row) {
    setRows((r) => r.map((x) => (x.id === row.id ? { ...x, handover_completed: !x.handover_completed } : x)))
    await updateReassignmentHandover(row.id, !row.handover_completed)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-knosk-slate">
          Internal moves also trigger a mandatory handover, per SOP — same rule as an exit.
        </p>
        <button onClick={openModal} className={`${buttonPrimary} flex items-center gap-1.5`}>
          <Plus size={16} /> New reassignment
        </button>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">Couldn't load reassignments — {error.message}</Card>
      )}

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-knosk-slate border-b border-knosk-line">
              <th className="px-5 py-3 font-medium">Staff</th>
              <th className="px-5 py-3 font-medium">From → To</th>
              <th className="px-5 py-3 font-medium">Effective</th>
              <th className="px-5 py-3 font-medium">Reason</th>
              <th className="px-5 py-3 font-medium">Handover</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="px-5 py-8 text-center text-knosk-slate">Loading…</td></tr>}
            {!loading && rows.length === 0 && !error && (
              <tr><td colSpan={5} className="px-5 py-8 text-center text-knosk-slate">No reassignments logged yet.</td></tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-knosk-line last:border-0">
                <td className="px-5 py-3 font-medium text-knosk-ink">{r.staff?.full_name}</td>
                <td className="px-5 py-3 text-knosk-slate">
                  {r.from_node?.title || '—'} <span className="text-knosk-line mx-1">→</span> {r.to_node?.title || '—'}
                </td>
                <td className="px-5 py-3 text-knosk-slate">{new Date(r.effective_date).toLocaleDateString()}</td>
                <td className="px-5 py-3 text-knosk-slate truncate max-w-[16rem]">{r.reason || '—'}</td>
                <td className="px-5 py-3">
                  <button
                    onClick={() => toggleHandover(r)}
                    className={`flex items-center gap-1.5 text-xs font-semibold px-2 py-1 rounded-full ${
                      r.handover_completed ? 'bg-emerald-50 text-emerald-700' : 'bg-orange-50 text-orange-700'
                    }`}
                  >
                    {r.handover_completed ? <Check size={12} /> : <AlertCircle size={12} />}
                    {r.handover_completed ? 'Completed' : 'Pending'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {modalOpen && (
        <Modal title="New reassignment" onClose={() => setModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            {saveError && <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{saveError}</div>}
            <Field label="Staff member">
              <select required className={inputCls} value={form.staffId} onChange={(e) => setForm({ ...form, staffId: e.target.value })}>
                <option value="">— select —</option>
                {staffOptions.map((s) => <option key={s.id} value={s.id}>{s.full_name}</option>)}
              </select>
            </Field>
            <Field label="New department / seat">
              <select required className={inputCls} value={form.toOrgNodeId} onChange={(e) => setForm({ ...form, toOrgNodeId: e.target.value })}>
                <option value="">— select —</option>
                {orgNodeOptions.map((n) => <option key={n.id} value={n.id}>{n.title}</option>)}
              </select>
            </Field>
            <Field label="Effective date">
              <input required type="date" className={inputCls} value={form.effectiveDate} onChange={(e) => setForm({ ...form, effectiveDate: e.target.value })} />
            </Field>
            <Field label="Reason">
              <textarea rows={3} className={inputCls} value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
            </Field>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className={buttonGhost}>Cancel</button>
              <button type="submit" disabled={saving} className={buttonPrimary}>{saving ? 'Saving…' : 'Create'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
