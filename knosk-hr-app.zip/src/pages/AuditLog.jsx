import { useEffect, useState } from 'react'
import { ChevronDown, ChevronRight } from 'lucide-react'
import { Card } from '../components/Card'
import { fetchAuditLog } from '../lib/queries'

const TABLES = ['staff', 'offer_letters', 'staff_access', 'offboarding_tasks', 'reassignments']

const ACTION_STYLE = {
  INSERT: 'bg-emerald-50 text-emerald-700',
  UPDATE: 'bg-knosk-blue-50 text-knosk-blue',
  DELETE: 'bg-red-50 text-red-600',
}

function diffFields(oldData, newData) {
  if (!oldData || !newData) return []
  const keys = new Set([...Object.keys(oldData), ...Object.keys(newData)])
  const changes = []
  for (const key of keys) {
    const a = JSON.stringify(oldData[key])
    const b = JSON.stringify(newData[key])
    if (a !== b) changes.push({ key, from: oldData[key], to: newData[key] })
  }
  return changes
}

function LogRow({ entry }) {
  const [open, setOpen] = useState(false)
  const changes = entry.action === 'UPDATE' ? diffFields(entry.old_data, entry.new_data) : []

  return (
    <div className="border-b border-knosk-line last:border-0">
      <button onClick={() => setOpen((v) => !v)} className="w-full flex items-center gap-3 px-5 py-3 text-left">
        {open ? <ChevronDown size={15} className="text-knosk-slate shrink-0" /> : <ChevronRight size={15} className="text-knosk-slate shrink-0" />}
        <span className={`text-xs font-semibold px-2 py-1 rounded-full shrink-0 ${ACTION_STYLE[entry.action] || 'bg-gray-100 text-gray-500'}`}>
          {entry.action}
        </span>
        <span className="text-sm text-knosk-ink font-medium shrink-0">{entry.table_name}</span>
        <span className="text-xs text-knosk-slate truncate">
          {entry.profile?.full_name ? `by ${entry.profile.full_name}` : 'system'} · {new Date(entry.created_at).toLocaleString()}
        </span>
      </button>
      {open && (
        <div className="px-5 pb-4 pl-11">
          {entry.action === 'UPDATE' && changes.length > 0 && (
            <table className="w-full text-xs border border-knosk-line rounded-lg overflow-hidden">
              <thead>
                <tr className="bg-knosk-blue-50 text-knosk-slate text-left">
                  <th className="px-3 py-1.5 font-medium">Field</th>
                  <th className="px-3 py-1.5 font-medium">From</th>
                  <th className="px-3 py-1.5 font-medium">To</th>
                </tr>
              </thead>
              <tbody>
                {changes.map((c) => (
                  <tr key={c.key} className="border-t border-knosk-line">
                    <td className="px-3 py-1.5 font-medium text-knosk-ink">{c.key}</td>
                    <td className="px-3 py-1.5 text-red-600">{String(c.from ?? '—')}</td>
                    <td className="px-3 py-1.5 text-emerald-700">{String(c.to ?? '—')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {entry.action === 'UPDATE' && changes.length === 0 && (
            <p className="text-xs text-knosk-slate">No field-level differences recorded.</p>
          )}
          {entry.action === 'INSERT' && (
            <pre className="text-xs bg-knosk-cream border border-knosk-line rounded-lg p-3 overflow-x-auto">
              {JSON.stringify(entry.new_data, null, 2)}
            </pre>
          )}
          {entry.action === 'DELETE' && (
            <pre className="text-xs bg-knosk-cream border border-knosk-line rounded-lg p-3 overflow-x-auto">
              {JSON.stringify(entry.old_data, null, 2)}
            </pre>
          )}
        </div>
      )}
    </div>
  )
}

export default function AuditLog() {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [tableName, setTableName] = useState('')

  useEffect(() => {
    setLoading(true)
    fetchAuditLog({ tableName: tableName || undefined, limit: 100 }).then(({ data, error }) => {
      setRows(data ?? [])
      setError(error)
      setLoading(false)
    })
  }, [tableName])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-knosk-slate">
          Every insert, update, and delete on the tables that matter — who did it, and what changed.
        </p>
        <div className="flex gap-2 flex-wrap">
          {['', ...TABLES].map((t) => (
            <button
              key={t || 'all'}
              onClick={() => setTableName(t)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
                tableName === t ? 'bg-knosk-navy text-white border-knosk-navy' : 'bg-white text-knosk-slate border-knosk-line hover:border-knosk-blue'
              }`}
            >
              {t === '' ? 'All tables' : t.replaceAll('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">Couldn't load the audit log — {error.message}</Card>
      )}

      <Card className="overflow-hidden">
        {loading && <p className="text-sm text-knosk-slate px-5 py-8 text-center">Loading…</p>}
        {!loading && rows.length === 0 && !error && (
          <p className="text-sm text-knosk-slate px-5 py-8 text-center">No activity recorded yet.</p>
        )}
        {rows.map((entry) => (
          <LogRow key={entry.id} entry={entry} />
        ))}
      </Card>
    </div>
  )
}
