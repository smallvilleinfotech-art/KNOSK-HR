import { useEffect, useState } from 'react'
import { AlertTriangle, Info, ShieldAlert, Check, RotateCcw } from 'lucide-react'
import { Card } from '../components/Card'
import { useAuth } from '../context/AuthContext'
import { fetchAlerts, resolveAlert, reopenAlert } from '../lib/queries'

const SEVERITY_ICON = { critical: ShieldAlert, warning: AlertTriangle, info: Info }
const SEVERITY_STYLE = {
  critical: 'text-red-600 bg-red-50',
  warning: 'text-knosk-gold bg-knosk-gold-50',
  info: 'text-knosk-blue bg-knosk-blue-50',
}

export default function Alerts() {
  const { profile } = useAuth()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [severity, setSeverity] = useState('')
  const [showResolved, setShowResolved] = useState(false)

  function load() {
    setLoading(true)
    fetchAlerts({ severity: severity || undefined, resolved: showResolved ? undefined : false }).then(
      ({ data, error }) => {
        setRows(data ?? [])
        setError(error)
        setLoading(false)
      }
    )
  }
  useEffect(load, [severity, showResolved])

  async function handleResolve(id) {
    setRows((r) => r.map((x) => (x.id === id ? { ...x, is_resolved: true } : x)))
    await resolveAlert(id, profile?.id)
    if (!showResolved) load()
  }

  async function handleReopen(id) {
    await reopenAlert(id)
    load()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-knosk-slate">
          Everything the system has flagged across staff, documents, access, and offboarding.
        </p>
        <div className="flex items-center gap-2 flex-wrap">
          {['', 'critical', 'warning', 'info'].map((s) => (
            <button
              key={s || 'all'}
              onClick={() => setSeverity(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
                severity === s ? 'bg-knosk-navy text-white border-knosk-navy' : 'bg-white text-knosk-slate border-knosk-line hover:border-knosk-blue'
              }`}
            >
              {s === '' ? 'All severities' : s}
            </button>
          ))}
          <label className="flex items-center gap-1.5 text-xs text-knosk-slate ml-2">
            <input type="checkbox" checked={showResolved} onChange={(e) => setShowResolved(e.target.checked)} />
            Show resolved
          </label>
        </div>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">Couldn't load alerts — {error.message}</Card>
      )}

      <Card className="overflow-hidden">
        {loading && <p className="text-sm text-knosk-slate px-5 py-8 text-center">Loading…</p>}
        {!loading && rows.length === 0 && !error && (
          <p className="text-sm text-knosk-slate px-5 py-8 text-center">Nothing here.</p>
        )}
        <ul className="divide-y divide-knosk-line">
          {rows.map((a) => {
            const Icon = SEVERITY_ICON[a.severity] ?? Info
            return (
              <li key={a.id} className="flex items-start gap-3 px-5 py-4">
                <span className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${SEVERITY_STYLE[a.severity]}`}>
                  <Icon size={16} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className={`text-sm ${a.is_resolved ? 'text-knosk-slate line-through' : 'text-knosk-ink'}`}>{a.message}</p>
                  <p className="text-xs text-knosk-slate mt-0.5">
                    {a.alert_type} · {a.staff?.full_name || a.org_node?.title || 'General'} ·{' '}
                    {new Date(a.created_at).toLocaleDateString()}
                  </p>
                </div>
                {a.is_resolved ? (
                  <button
                    onClick={() => handleReopen(a.id)}
                    className="flex items-center gap-1.5 text-xs font-semibold text-knosk-slate hover:text-knosk-blue shrink-0"
                  >
                    <RotateCcw size={13} /> Reopen
                  </button>
                ) : (
                  <button
                    onClick={() => handleResolve(a.id)}
                    className="flex items-center gap-1.5 text-xs font-semibold text-knosk-blue hover:underline shrink-0"
                  >
                    <Check size={13} /> Resolve
                  </button>
                )}
              </li>
            )
          })}
        </ul>
      </Card>
    </div>
  )
}
