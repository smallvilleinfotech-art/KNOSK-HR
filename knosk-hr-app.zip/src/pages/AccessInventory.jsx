import { useEffect, useState } from 'react'
import { Plus, ShieldOff } from 'lucide-react'
import { Card } from '../components/Card'
import Modal from '../components/Modal'
import { Field, inputCls, buttonPrimary, buttonGhost } from '../components/FormField'
import { useAuth } from '../context/AuthContext'
import {
  fetchStaffAccessInventory,
  revokeAccess,
  grantAccess,
  fetchAccessSystems,
  fetchAllStaffForSelect,
} from '../lib/queries'

const STATUS_STYLE = {
  requested: 'bg-knosk-gold-50 text-knosk-gold',
  active: 'bg-emerald-50 text-emerald-700',
  pending_revocation: 'bg-orange-50 text-orange-700',
  revoked: 'bg-gray-100 text-gray-500',
}

export default function AccessInventory() {
  const { profile } = useAuth()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [staffOptions, setStaffOptions] = useState([])
  const [systemOptions, setSystemOptions] = useState([])
  const [form, setForm] = useState({ staffId: '', accessSystemId: '' })
  const [saving, setSaving] = useState(false)

  function load() {
    setLoading(true)
    fetchStaffAccessInventory().then(({ data, error }) => {
      setRows(data ?? [])
      setError(error)
      setLoading(false)
    })
  }
  useEffect(load, [])

  function openGrantModal() {
    fetchAllStaffForSelect().then(({ data }) => setStaffOptions(data ?? []))
    fetchAccessSystems().then(({ data }) => setSystemOptions(data ?? []))
    setForm({ staffId: '', accessSystemId: '' })
    setModalOpen(true)
  }

  async function handleRevoke(id) {
    setRows((r) => r.map((row) => (row.id === id ? { ...row, status: 'revoked' } : row)))
    await revokeAccess(id, profile?.id)
  }

  async function handleGrant(e) {
    e.preventDefault()
    setSaving(true)
    await grantAccess({ staffId: form.staffId, accessSystemId: form.accessSystemId, grantedBy: profile?.id })
    setSaving(false)
    setModalOpen(false)
    load()
  }

  const offboardingHoldingAccess = rows.filter(
    (r) => r.status === 'active' && r.staff?.employment_status === 'offboarding'
  )

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-knosk-slate">Who has access to what — and what's still live after someone leaves.</p>
        <button onClick={openGrantModal} className={`${buttonPrimary} flex items-center gap-1.5`}>
          <Plus size={16} /> Grant access
        </button>
      </div>

      {offboardingHoldingAccess.length > 0 && (
        <Card className="p-4 border-orange-200 bg-orange-50 text-sm text-orange-800 flex items-center gap-2">
          <ShieldOff size={16} />
          {offboardingHoldingAccess.length} active access grant(s) belong to staff currently offboarding — revoke before they exit.
        </Card>
      )}

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">Couldn't load access inventory — {error.message}</Card>
      )}

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-knosk-slate border-b border-knosk-line">
              <th className="px-5 py-3 font-medium">Staff</th>
              <th className="px-5 py-3 font-medium">System / access</th>
              <th className="px-5 py-3 font-medium">Category</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="px-5 py-8 text-center text-knosk-slate">Loading…</td></tr>}
            {!loading && rows.length === 0 && !error && (
              <tr><td colSpan={5} className="px-5 py-8 text-center text-knosk-slate">No access records yet.</td></tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} className="border-b border-knosk-line last:border-0">
                <td className="px-5 py-3 font-medium text-knosk-ink">{r.staff?.full_name}</td>
                <td className="px-5 py-3 text-knosk-slate">{r.access_system?.name}</td>
                <td className="px-5 py-3 text-knosk-slate capitalize">{r.access_system?.category}</td>
                <td className="px-5 py-3">
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${STATUS_STYLE[r.status]}`}>
                    {r.status.replaceAll('_', ' ')}
                  </span>
                </td>
                <td className="px-5 py-3 text-right">
                  {r.status === 'active' && (
                    <button onClick={() => handleRevoke(r.id)} className="text-xs font-semibold text-red-600 hover:underline">
                      Revoke
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {modalOpen && (
        <Modal title="Grant access" onClose={() => setModalOpen(false)}>
          <form onSubmit={handleGrant} className="space-y-4">
            <Field label="Staff member">
              <select required className={inputCls} value={form.staffId} onChange={(e) => setForm({ ...form, staffId: e.target.value })}>
                <option value="">— select —</option>
                {staffOptions.map((s) => <option key={s.id} value={s.id}>{s.full_name}</option>)}
              </select>
            </Field>
            <Field label="Access system">
              <select required className={inputCls} value={form.accessSystemId} onChange={(e) => setForm({ ...form, accessSystemId: e.target.value })}>
                <option value="">— select —</option>
                {systemOptions.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </Field>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setModalOpen(false)} className={buttonGhost}>Cancel</button>
              <button type="submit" disabled={saving} className={buttonPrimary}>{saving ? 'Granting…' : 'Grant access'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
