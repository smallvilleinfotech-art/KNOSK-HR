import { useEffect, useState } from 'react'
import { AlertTriangle, Info, ShieldAlert, ArrowUpRight } from 'lucide-react'
import { Card, StatCard } from '../components/Card'
import {
  fetchLeadershipDashboard,
  fetchOpenAlerts,
  fetchOnboardingProgress,
  fetchOffboardingClearance,
} from '../lib/queries'

const SEVERITY_ICON = { critical: ShieldAlert, warning: AlertTriangle, info: Info }
const SEVERITY_STYLE = {
  critical: 'text-red-600 bg-red-50',
  warning: 'text-knosk-gold bg-knosk-gold-50',
  info: 'text-knosk-blue bg-knosk-blue-50',
}

function useAsync(fetcher, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true })
  useEffect(() => {
    let alive = true
    setState((s) => ({ ...s, loading: true }))
    fetcher().then(({ data, error }) => {
      if (!alive) return
      setState({ data, error, loading: false })
    })
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
  return state
}

export default function Dashboard() {
  const leadership = useAsync(fetchLeadershipDashboard)
  const alerts = useAsync(() => fetchOpenAlerts(8))
  const onboarding = useAsync(() => fetchOnboardingProgress(6))
  const offboarding = useAsync(fetchOffboardingClearance)

  const rows = leadership.data ?? []
  const totalActive = rows.reduce((sum, r) => sum + (r.active_staff ?? 0), 0)
  const totalProbation = rows.reduce((sum, r) => sum + (r.on_probation ?? 0), 0)
  const totalOffboarding = rows.reduce((sum, r) => sum + (r.offboarding ?? 0), 0)
  const totalProbationEnding = rows.reduce((sum, r) => sum + (r.probation_ending_soon ?? 0), 0)

  return (
    <div className="space-y-6">
      {(leadership.error || alerts.error) && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">
          Couldn't reach Supabase — check that <code>.env</code> has your project URL/anon key
          and that the schema has been applied. ({leadership.error?.message || alerts.error?.message})
        </Card>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Active staff" value={leadership.loading ? '—' : totalActive} accent="blue" />
        <StatCard label="On probation" value={leadership.loading ? '—' : totalProbation} accent="gold" />
        <StatCard label="In offboarding" value={leadership.loading ? '—' : totalOffboarding} accent="navy" />
        <StatCard
          label="Probation ending (14d)"
          value={leadership.loading ? '—' : totalProbationEnding}
          accent="gold"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Alerts feed */}
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-knosk-navy">Alerts &amp; flags</h2>
            <span className="text-xs text-knosk-slate">Needs attention</span>
          </div>

          {alerts.loading && <p className="text-sm text-knosk-slate">Loading alerts…</p>}
          {!alerts.loading && (alerts.data ?? []).length === 0 && (
            <p className="text-sm text-knosk-slate">Nothing flagged right now.</p>
          )}

          <ul className="divide-y divide-knosk-line">
            {(alerts.data ?? []).map((a) => {
              const Icon = SEVERITY_ICON[a.severity] ?? Info
              return (
                <li key={a.id} className="flex items-start gap-3 py-3">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${SEVERITY_STYLE[a.severity]}`}>
                    <Icon size={15} />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm text-knosk-ink">{a.message}</p>
                    <p className="text-xs text-knosk-slate mt-0.5">
                      {a.staff?.full_name ? `${a.staff.full_name} · ` : ''}
                      {new Date(a.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </li>
              )
            })}
          </ul>
        </Card>

        {/* Onboarding progress */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-knosk-navy">Onboarding in progress</h2>
          </div>
          {onboarding.loading && <p className="text-sm text-knosk-slate">Loading…</p>}
          {!onboarding.loading && (onboarding.data ?? []).length === 0 && (
            <p className="text-sm text-knosk-slate">No one currently mid-onboarding.</p>
          )}
          <ul className="space-y-4">
            {(onboarding.data ?? []).map((o) => (
              <li key={o.staff_id}>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="font-medium text-knosk-ink truncate">{o.full_name}</span>
                  <span className="text-knosk-slate">{o.pct_complete ?? 0}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-knosk-line overflow-hidden">
                  <div
                    className="h-full bg-knosk-blue rounded-full"
                    style={{ width: `${o.pct_complete ?? 0}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {/* Offboarding clearance blockers */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-knosk-navy">Blocked exits</h2>
          <span className="text-xs text-knosk-slate">Mandatory handover incomplete</span>
        </div>
        {offboarding.loading && <p className="text-sm text-knosk-slate">Loading…</p>}
        {!offboarding.loading && (offboarding.data ?? []).length === 0 && (
          <p className="text-sm text-knosk-slate">No pending exits are blocked.</p>
        )}
        <ul className="divide-y divide-knosk-line">
          {(offboarding.data ?? []).map((o) => (
            <li key={o.staff_id} className="flex items-center justify-between py-2.5 text-sm">
              <span className="text-knosk-ink font-medium">{o.full_name}</span>
              <span className="flex items-center gap-1 text-knosk-gold">
                {o.mandatory_completed}/{o.mandatory_tasks} handover tasks done
                <ArrowUpRight size={14} />
              </span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
