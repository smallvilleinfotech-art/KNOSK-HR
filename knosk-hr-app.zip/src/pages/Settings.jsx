import { useEffect, useState } from 'react'
import { Bell } from 'lucide-react'
import { Card } from '../components/Card'
import { Field, inputCls, buttonPrimary } from '../components/FormField'
import { useAuth } from '../context/AuthContext'
import {
  fetchProfiles,
  updateProfileRole,
  updateProfileActive,
  fetchMyNotificationPreferences,
  upsertNotificationPreferences,
} from '../lib/queries'

const ROLES = [
  'super_admin',
  'hr_admin',
  'head_of_ops',
  'principal',
  'vice_principal',
  'department_head',
  'manager',
  'staff_viewer',
]

const CAN_MANAGE_ROLES = new Set(['super_admin', 'hr_admin'])

function NotificationPreferencesPanel() {
  const { profile } = useAuth()
  const [prefs, setPrefs] = useState({ email_enabled: true, whatsapp_enabled: false, whatsapp_number: '' })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (!profile?.id) return
    fetchMyNotificationPreferences(profile.id).then(({ data }) => {
      if (data) setPrefs(data)
      setLoading(false)
    })
  }, [profile?.id])

  async function handleSave(e) {
    e.preventDefault()
    setSaving(true)
    setSaved(false)
    const { error } = await upsertNotificationPreferences(profile.id, {
      email_enabled: prefs.email_enabled,
      whatsapp_enabled: prefs.whatsapp_enabled,
      whatsapp_number: prefs.whatsapp_number || null,
    })
    setSaving(false)
    if (!error) setSaved(true)
  }

  if (loading) return null

  return (
    <Card className="p-5">
      <h3 className="font-display font-bold text-knosk-navy mb-1 flex items-center gap-1.5">
        <Bell size={15} /> How you're notified
      </h3>
      <p className="text-sm text-knosk-slate mb-4">
        Critical and warning alerts get queued for HR admins. Email sending requires a provider to be
        configured (see the README) — until then, alerts still show up live in the Alerts tab regardless.
      </p>
      <form onSubmit={handleSave} className="space-y-3 max-w-sm">
        <label className="flex items-center gap-2 text-sm text-knosk-ink">
          <input
            type="checkbox"
            checked={prefs.email_enabled}
            onChange={(e) => setPrefs({ ...prefs, email_enabled: e.target.checked })}
          />
          Email me
        </label>
        <label className="flex items-center gap-2 text-sm text-knosk-ink">
          <input
            type="checkbox"
            checked={prefs.whatsapp_enabled}
            onChange={(e) => setPrefs({ ...prefs, whatsapp_enabled: e.target.checked })}
          />
          WhatsApp me
        </label>
        {prefs.whatsapp_enabled && (
          <Field label="WhatsApp number">
            <input
              className={inputCls}
              placeholder="+234…"
              value={prefs.whatsapp_number ?? ''}
              onChange={(e) => setPrefs({ ...prefs, whatsapp_number: e.target.value })}
            />
          </Field>
        )}
        <div className="flex items-center gap-3">
          <button type="submit" disabled={saving} className={buttonPrimary}>
            {saving ? 'Saving…' : 'Save preferences'}
          </button>
          {saved && <span className="text-xs text-emerald-700">Saved.</span>}
        </div>
      </form>
    </Card>
  )
}

export default function Settings() {
  const { profile: currentProfile } = useAuth()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const canManage = CAN_MANAGE_ROLES.has(currentProfile?.role)

  function load() {
    setLoading(true)
    fetchProfiles().then(({ data, error }) => {
      setRows(data ?? [])
      setError(error)
      setLoading(false)
    })
  }
  useEffect(load, [])

  async function handleRoleChange(id, role) {
    setRows((r) => r.map((x) => (x.id === id ? { ...x, role } : x)))
    const { error } = await updateProfileRole(id, role)
    if (error) load() // revert to server truth if the write was rejected (e.g. by RLS)
  }

  async function handleActiveToggle(id, isActive) {
    setRows((r) => r.map((x) => (x.id === id ? { ...x, is_active: isActive } : x)))
    const { error } = await updateProfileActive(id, isActive)
    if (error) load()
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-knosk-slate max-w-2xl">
        Every screen and row in this system checks the signed-in user's role via Postgres row-level
        security — this isn't just a UI filter, access is enforced at the database.
      </p>

      {!canManage && (
        <Card className="p-4 border-knosk-gold bg-knosk-gold-50 text-sm text-knosk-gold">
          You're viewing this in read-only mode — only <code>hr_admin</code> and <code>super_admin</code> can change roles.
        </Card>
      )}

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">Couldn't load accounts — {error.message}</Card>
      )}

      <NotificationPreferencesPanel />

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-knosk-slate border-b border-knosk-line">
              <th className="px-5 py-3 font-medium">Name</th>
              <th className="px-5 py-3 font-medium">Email</th>
              <th className="px-5 py-3 font-medium">Role</th>
              <th className="px-5 py-3 font-medium">Active</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={4} className="px-5 py-8 text-center text-knosk-slate">Loading…</td></tr>}
            {!loading && rows.length === 0 && !error && (
              <tr><td colSpan={4} className="px-5 py-8 text-center text-knosk-slate">No accounts yet.</td></tr>
            )}
            {rows.map((p) => (
              <tr key={p.id} className="border-b border-knosk-line last:border-0">
                <td className="px-5 py-3 font-medium text-knosk-ink">{p.full_name}</td>
                <td className="px-5 py-3 text-knosk-slate">{p.email}</td>
                <td className="px-5 py-3">
                  <select
                    disabled={!canManage}
                    value={p.role}
                    onChange={(e) => handleRoleChange(p.id, e.target.value)}
                    className="text-xs font-semibold bg-knosk-blue-50 text-knosk-blue px-2 py-1.5 rounded-lg border-0 outline-none disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {ROLES.map((r) => (
                      <option key={r} value={r}>{r.replaceAll('_', ' ')}</option>
                    ))}
                  </select>
                </td>
                <td className="px-5 py-3">
                  <button
                    disabled={!canManage}
                    onClick={() => handleActiveToggle(p.id, !p.is_active)}
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full disabled:opacity-60 disabled:cursor-not-allowed ${
                      p.is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    {p.is_active ? 'Active' : 'Deactivated'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  )
}
