import { useEffect, useState } from 'react'
import { Search, ChevronLeft, ChevronRight, UserPlus, Upload } from 'lucide-react'
import { Card } from '../components/Card'
import { buttonPrimary, buttonGhost } from '../components/FormField'
import AddStaffModal from '../components/AddStaffModal'
import BulkImportModal from '../components/BulkImportModal'
import { fetchStaffList } from '../lib/queries'

const STATUS_STYLE = {
  active: 'bg-emerald-50 text-emerald-700',
  probation: 'bg-knosk-gold-50 text-knosk-gold',
  on_leave: 'bg-knosk-blue-50 text-knosk-blue',
  reassigning: 'bg-knosk-blue-50 text-knosk-blue',
  offboarding: 'bg-orange-50 text-orange-700',
  terminated: 'bg-red-50 text-red-600',
  resigned: 'bg-red-50 text-red-600',
  archived: 'bg-gray-100 text-gray-500',
}

const PAGE_SIZE = 20

export default function StaffRegistry() {
  const [search, setSearch] = useState('')
  const [track, setTrack] = useState('')
  const [page, setPage] = useState(0)
  const [addOpen, setAddOpen] = useState(false)
  const [importOpen, setImportOpen] = useState(false)
  const [reloadKey, setReloadKey] = useState(0)
  const [{ data, count, error, loading }, setResult] = useState({
    data: [], count: 0, error: null, loading: true,
  })

  useEffect(() => {
    let alive = true
    setResult((r) => ({ ...r, loading: true }))
    fetchStaffList({ search, track: track || undefined, page, pageSize: PAGE_SIZE }).then(
      ({ data, count, error }) => {
        if (!alive) return
        setResult({ data: data ?? [], count: count ?? 0, error, loading: false })
      }
    )
    return () => { alive = false }
  }, [search, track, page, reloadKey])

  const totalPages = Math.max(1, Math.ceil(count / PAGE_SIZE))

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 bg-white border border-knosk-line rounded-full px-3.5 py-2 w-full sm:w-72">
          <Search size={16} className="text-knosk-slate" />
          <input
            value={search}
            onChange={(e) => { setPage(0); setSearch(e.target.value) }}
            placeholder="Search by name…"
            className="bg-transparent text-sm outline-none w-full placeholder:text-knosk-slate/70"
          />
        </div>
        <div className="flex gap-2 items-center flex-wrap">
          {['', 'ngo', 'academic'].map((t) => (
            <button
              key={t || 'all'}
              onClick={() => { setPage(0); setTrack(t) }}
              className={`px-3.5 py-2 rounded-full text-xs font-semibold border transition-colors ${
                track === t
                  ? 'bg-knosk-navy text-white border-knosk-navy'
                  : 'bg-white text-knosk-slate border-knosk-line hover:border-knosk-blue'
              }`}
            >
              {t === '' ? 'All tracks' : t === 'ngo' ? 'NGO' : 'Academic'}
            </button>
          ))}
          <button onClick={() => setImportOpen(true)} className={`${buttonGhost} flex items-center gap-1.5`}>
            <Upload size={15} /> Import CSV
          </button>
          <button onClick={() => setAddOpen(true)} className={`${buttonPrimary} flex items-center gap-1.5`}>
            <UserPlus size={15} /> Add staff
          </button>
        </div>
      </div>

      {error && (
        <Card className="p-4 border-red-200 bg-red-50 text-sm text-red-700">
          Couldn't load staff — {error.message}
        </Card>
      )}

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-knosk-slate border-b border-knosk-line">
              <th className="px-5 py-3 font-medium">Name</th>
              <th className="px-5 py-3 font-medium">Job title</th>
              <th className="px-5 py-3 font-medium">Track</th>
              <th className="px-5 py-3 font-medium">Entity</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium">Start date</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={6} className="px-5 py-8 text-center text-knosk-slate">Loading staff…</td></tr>
            )}
            {!loading && data.length === 0 && !error && (
              <tr><td colSpan={6} className="px-5 py-8 text-center text-knosk-slate">No staff match this filter.</td></tr>
            )}
            {data.map((s) => (
              <tr key={s.id} className="border-b border-knosk-line last:border-0 hover:bg-knosk-blue-50/40 cursor-pointer">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-full bg-knosk-navy text-white text-xs font-semibold flex items-center justify-center shrink-0">
                      {s.full_name?.split(' ').map((p) => p[0]).slice(0, 2).join('')}
                    </span>
                    <span className="font-medium text-knosk-ink">{s.full_name}</span>
                  </div>
                </td>
                <td className="px-5 py-3 text-knosk-slate">{s.job_title}</td>
                <td className="px-5 py-3">
                  <span className="text-xs font-semibold uppercase text-knosk-slate">{s.track}</span>
                </td>
                <td className="px-5 py-3 text-knosk-slate truncate max-w-[14rem]">{s.entity?.name}</td>
                <td className="px-5 py-3">
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full ${STATUS_STYLE[s.employment_status] || 'bg-gray-100 text-gray-500'}`}>
                    {s.employment_status?.replaceAll('_', ' ')}
                  </span>
                </td>
                <td className="px-5 py-3 text-knosk-slate">
                  {s.start_date ? new Date(s.start_date).toLocaleDateString() : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex items-center justify-between px-5 py-3 border-t border-knosk-line text-sm text-knosk-slate">
          <span>{count} staff total</span>
          <div className="flex items-center gap-2">
            <button
              disabled={page === 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              className="p-1.5 rounded-lg border border-knosk-line disabled:opacity-40 hover:border-knosk-blue"
            >
              <ChevronLeft size={15} />
            </button>
            <span>{page + 1} / {totalPages}</span>
            <button
              disabled={page + 1 >= totalPages}
              onClick={() => setPage((p) => p + 1)}
              className="p-1.5 rounded-lg border border-knosk-line disabled:opacity-40 hover:border-knosk-blue"
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      </Card>

      {addOpen && (
        <AddStaffModal
          onClose={() => setAddOpen(false)}
          onCreated={() => { setAddOpen(false); setReloadKey((k) => k + 1) }}
        />
      )}
      {importOpen && (
        <BulkImportModal
          onClose={() => setImportOpen(false)}
          onImported={() => setReloadKey((k) => k + 1)}
        />
      )}
    </div>
  )
}
