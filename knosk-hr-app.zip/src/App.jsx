import { HashRouter, Routes, Route } from 'react-router-dom'
import { Suspense, lazy } from 'react'
import { AuthProvider } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import AppShell from './layouts/AppShell'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import StaffRegistry from './pages/StaffRegistry'
import JobDescriptions from './pages/JobDescriptions'
import Onboarding from './pages/Onboarding'
import Offboarding from './pages/Offboarding'
import Documents from './pages/Documents'
import AccessInventory from './pages/AccessInventory'
import Reassignments from './pages/Reassignments'
import Alerts from './pages/Alerts'
import AuditLog from './pages/AuditLog'
import Settings from './pages/Settings'

const OrgChart3D = lazy(() => import('./pages/OrgChart3D'))

export default function App() {
  return (
    <AuthProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route
            element={
              <ProtectedRoute>
                <AppShell />
              </ProtectedRoute>
            }
          >
            <Route index element={<Dashboard />} handle={{ title: 'Dashboard', subtitle: 'NGO & School, at a glance' }} />
            <Route path="staff" element={<StaffRegistry />} handle={{ title: 'Staff Registry' }} />
            <Route
              path="job-descriptions"
              element={<JobDescriptions />}
              handle={{ title: 'Job Descriptions', subtitle: 'Source of truth for offer letters' }}
            />
            <Route
              path="onboarding"
              element={<Onboarding />}
              handle={{ title: 'Onboarding', subtitle: 'Role & track-specific checklists' }}
            />
            <Route
              path="offboarding"
              element={<Offboarding />}
              handle={{ title: 'Offboarding', subtitle: 'No exit without a completed handover' }}
            />
            <Route
              path="documents"
              element={<Documents />}
              handle={{ title: 'Documents', subtitle: 'Document inventory per staff member' }}
            />
            <Route
              path="access"
              element={<AccessInventory />}
              handle={{ title: 'Access Inventory', subtitle: 'Grants, categories, and revocations' }}
            />
            <Route
              path="reassignments"
              element={<Reassignments />}
              handle={{ title: 'Reassignments', subtitle: 'Internal moves also require a handover' }}
            />
            <Route
              path="org-chart"
              element={
                <Suspense
                  fallback={<div className="text-sm text-knosk-slate py-10 text-center">Loading 3D view…</div>}
                >
                  <OrgChart3D />
                </Suspense>
              }
              handle={{ title: 'Org Chart (3D)', subtitle: 'Live, linked to the staff registry' }}
            />
            <Route
              path="alerts"
              element={<Alerts />}
              handle={{ title: 'Alerts & Flags', subtitle: 'Everything the system has flagged' }}
            />
            <Route
              path="audit-log"
              element={<AuditLog />}
              handle={{ title: 'Audit Log', subtitle: 'Who changed what, and when' }}
            />
            <Route
              path="settings"
              element={<Settings />}
              handle={{ title: 'Settings', subtitle: 'Roles & permissions' }}
            />
          </Route>
        </Routes>
      </HashRouter>
    </AuthProvider>
  )
}
