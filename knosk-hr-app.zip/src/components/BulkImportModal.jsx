import { useState } from 'react'
import Papa from 'papaparse'
import { Upload, FileWarning, CheckCircle2, XCircle } from 'lucide-react'
import Modal from './Modal'
import { buttonPrimary, buttonGhost } from './FormField'
import { fetchEntities, bulkCreateStaff } from '../lib/queries'

const REQUIRED_COLUMNS = ['full_name', 'track', 'job_title', 'start_date']
const OPTIONAL_COLUMNS = ['email', 'staff_category', 'employment_status']

function normalizeRow(row, entitiesByTrack) {
  const track = (row.track || '').trim().toLowerCase()
  if (track !== 'ngo' && track !== 'academic') {
    return { error: `track must be "ngo" or "academic", got "${row.track}"` }
  }
  if (!row.full_name?.trim()) return { error: 'full_name is required' }
  if (!row.job_title?.trim()) return { error: 'job_title is required' }
  if (!row.start_date?.trim()) return { error: 'start_date is required (YYYY-MM-DD)' }

  const entity = entitiesByTrack[track]
  if (!entity) return { error: `No entity found for track "${track}"` }

  return {
    payload: {
      full_name: row.full_name.trim(),
      email: row.email?.trim() || null,
      track,
      entity_id: entity.id,
      job_title: row.job_title.trim(),
      staff_category: (row.staff_category?.trim() || 'fulltime'),
      employment_status: row.employment_status?.trim() || 'probation',
      start_date: row.start_date.trim(),
    },
  }
}

export default function BulkImportModal({ onClose, onImported }) {
  const [rawRows, setRawRows] = useState(null)
  const [fileName, setFileName] = useState(null)
  const [parseError, setParseError] = useState(null)
  const [importing, setImporting] = useState(false)
  const [results, setResults] = useState(null)

  function handleFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setFileName(file.name)
    setParseError(null)
    setResults(null)
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (res) => {
        const headers = res.meta.fields ?? []
        const missing = REQUIRED_COLUMNS.filter((c) => !headers.includes(c))
        if (missing.length > 0) {
          setParseError(`Missing required column(s): ${missing.join(', ')}`)
          setRawRows(null)
          return
        }
        setRawRows(res.data)
      },
      error: (err) => setParseError(err.message),
    })
  }

  async function handleImport() {
    setImporting(true)
    const { data: entities } = await fetchEntities()
    const entitiesByTrack = Object.fromEntries((entities ?? []).map((e) => [e.track, e]))

    const normalized = rawRows.map((row) => ({ row, ...normalizeRow(row, entitiesByTrack) }))
    const validPayloads = normalized.filter((n) => n.payload).map((n) => n.payload)
    const preValidationErrors = normalized.filter((n) => n.error)

    const insertResults = await bulkCreateStaff(validPayloads)
    setImporting(false)

    const succeeded = insertResults.filter((r) => !r.error).length
    const failed = insertResults.filter((r) => r.error).map((r) => ({
      name: r.input.full_name,
      message: r.error.message,
    }))

    setResults({
      succeeded,
      failed: [...preValidationErrors.map((n) => ({ name: n.row.full_name || '(blank)', message: n.error })), ...failed],
      total: rawRows.length,
    })

    if (succeeded > 0) onImported()
  }

  return (
    <Modal title="Bulk import staff" onClose={onClose} wide>
      <div className="space-y-4">
        <div className="text-sm text-knosk-slate">
          CSV must include columns: <code className="text-knosk-blue">{REQUIRED_COLUMNS.join(', ')}</code>.
          Optional: <code className="text-knosk-blue">{OPTIONAL_COLUMNS.join(', ')}</code>. Each imported row
          automatically gets its onboarding checklist and document inventory generated, same as adding one
          person by hand — this is just the same thing at volume.
        </div>

        <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-knosk-line rounded-xl py-8 cursor-pointer hover:border-knosk-blue transition-colors">
          <Upload size={22} className="text-knosk-slate" />
          <span className="text-sm text-knosk-slate">{fileName || 'Click to choose a CSV file'}</span>
          <input type="file" accept=".csv" className="hidden" onChange={handleFile} />
        </label>

        {parseError && (
          <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
            <FileWarning size={15} /> {parseError}
          </div>
        )}

        {rawRows && !results && (
          <div>
            <p className="text-sm text-knosk-ink font-medium mb-2">{rawRows.length} row(s) ready to import — preview:</p>
            <div className="border border-knosk-line rounded-lg overflow-x-auto max-h-56 overflow-y-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-knosk-blue-50 text-knosk-slate text-left">
                    {Object.keys(rawRows[0]).map((h) => <th key={h} className="px-3 py-1.5 font-medium">{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {rawRows.slice(0, 5).map((row, i) => (
                    <tr key={i} className="border-t border-knosk-line">
                      {Object.keys(rawRows[0]).map((h) => <td key={h} className="px-3 py-1.5 text-knosk-ink">{row[h]}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {results && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-emerald-700">
              <CheckCircle2 size={16} /> {results.succeeded} of {results.total} imported successfully
            </div>
            {results.failed.length > 0 && (
              <div className="border border-red-100 bg-red-50 rounded-lg p-3 space-y-1 max-h-40 overflow-y-auto">
                {results.failed.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-red-700">
                    <XCircle size={13} className="mt-0.5 shrink-0" />
                    <span><span className="font-semibold">{f.name}</span> — {f.message}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className={buttonGhost}>
            {results ? 'Close' : 'Cancel'}
          </button>
          {rawRows && !results && (
            <button onClick={handleImport} disabled={importing} className={buttonPrimary}>
              {importing ? 'Importing…' : `Import ${rawRows.length} staff`}
            </button>
          )}
        </div>
      </div>
    </Modal>
  )
}
