import { useEffect, useState } from 'react'
import Modal from '../components/Modal'
import { Field, inputCls, buttonPrimary, buttonGhost } from '../components/FormField'
import { useAuth } from '../context/AuthContext'
import { createStaff, fetchEntities, fetchOrgNodesForSelect, fetchJobDescriptions } from '../lib/queries'

const emptyForm = {
  fullName: '',
  email: '',
  track: 'ngo',
  entityId: '',
  orgNodeId: '',
  jobDescriptionId: '',
  jobTitle: '',
  staffCategory: 'fulltime',
  startDate: '',
  guarantorOnFile: false,
  safeguardingCleared: false,
}

export default function AddStaffModal({ onClose, onCreated }) {
  const { profile } = useAuth()
  const [form, setForm] = useState(emptyForm)
  const [entities, setEntities] = useState([])
  const [orgNodes, setOrgNodes] = useState([])
  const [jds, setJds] = useState([])
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchEntities().then(({ data }) => setEntities(data ?? []))
  }, [])

  useEffect(() => {
    fetchOrgNodesForSelect(form.track).then(({ data }) => setOrgNodes(data ?? []))
    fetchJobDescriptions().then(({ data }) => setJds((data ?? []).filter((j) => j.track === form.track)))
    const matchingEntity = entities.find((e) => e.track === form.track)
    if (matchingEntity) setForm((f) => ({ ...f, entityId: matchingEntity.id }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.track, entities])

  function handleJdChange(jdId) {
    const jd = jds.find((j) => j.id === jdId)
    setForm((f) => ({ ...f, jobDescriptionId: jdId, jobTitle: jd ? jd.title : f.jobTitle }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setError(null)

    const { error } = await createStaff({
      full_name: form.fullName.trim(),
      email: form.email.trim() || null,
      track: form.track,
      entity_id: form.entityId || null,
      org_node_id: form.orgNodeId || null,
      job_description_id: form.jobDescriptionId || null,
      job_title: form.jobTitle.trim(),
      staff_category: form.staffCategory,
      start_date: form.startDate,
      guarantor_on_file: form.guarantorOnFile,
      safeguarding_cleared: form.track === 'academic' ? form.safeguardingCleared : false,
      created_by: profile?.id,
    })

    setSaving(false)
    if (error) {
      setError(error.message)
      return
    }
    onCreated()
  }

  return (
    <Modal title="Add staff member" onClose={onClose} wide>
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</div>}

        <div className="grid grid-cols-2 gap-4">
          <Field label="Full name">
            <input required className={inputCls} value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </Field>
          <Field label="Email">
            <input type="email" className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Track">
            <select className={inputCls} value={form.track} onChange={(e) => setForm({ ...form, track: e.target.value, orgNodeId: '', jobDescriptionId: '' })}>
              <option value="ngo">NGO</option>
              <option value="academic">Academic</option>
            </select>
          </Field>
          <Field label="Department / seat">
            <select className={inputCls} value={form.orgNodeId} onChange={(e) => setForm({ ...form, orgNodeId: e.target.value })}>
              <option value="">— select —</option>
              {orgNodes.map((n) => <option key={n.id} value={n.id}>{n.title}</option>)}
            </select>
          </Field>
        </div>

        <Field label="Job description (optional — leaving this unset skips the exact-title match check)">
          <select className={inputCls} value={form.jobDescriptionId} onChange={(e) => handleJdChange(e.target.value)}>
            <option value="">— none —</option>
            {jds.map((j) => <option key={j.id} value={j.id}>{j.title}</option>)}
          </select>
        </Field>

        <Field label="Job title">
          <input
            required
            className={inputCls}
            value={form.jobTitle}
            onChange={(e) => setForm({ ...form, jobTitle: e.target.value })}
            disabled={!!form.jobDescriptionId}
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Staff category">
            <select className={inputCls} value={form.staffCategory} onChange={(e) => setForm({ ...form, staffCategory: e.target.value })}>
              <option value="fulltime">Full-time</option>
              <option value="part_time">Part-time</option>
              <option value="volunteer">Volunteer</option>
              <option value="nysc">NYSC</option>
              <option value="intern">Intern</option>
            </select>
          </Field>
          <Field label="Start date">
            <input required type="date" className={inputCls} value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
          </Field>
        </div>

        <div className="flex flex-col gap-2">
          <label className="flex items-center gap-2 text-sm text-knosk-ink">
            <input type="checkbox" checked={form.guarantorOnFile} onChange={(e) => setForm({ ...form, guarantorOnFile: e.target.checked })} />
            Guarantor form on file
          </label>
          {form.track === 'academic' && (
            <label className="flex items-center gap-2 text-sm text-knosk-ink">
              <input type="checkbox" checked={form.safeguardingCleared} onChange={(e) => setForm({ ...form, safeguardingCleared: e.target.checked })} />
              Safeguarding declaration signed &amp; cleared (SOP Annex A — required before offer)
            </label>
          )}
        </div>

        <p className="text-xs text-knosk-slate">
          Saving will automatically generate this person's onboarding checklist and document
          inventory — no separate setup step needed.
        </p>

        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className={buttonGhost}>Cancel</button>
          <button type="submit" disabled={saving} className={buttonPrimary}>{saving ? 'Creating…' : 'Create staff record'}</button>
        </div>
      </form>
    </Modal>
  )
}
