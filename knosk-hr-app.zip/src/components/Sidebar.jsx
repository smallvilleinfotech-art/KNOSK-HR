import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  Users,
  FileText,
  ClipboardCheck,
  DoorOpen,
  FolderLock,
  KeyRound,
  Repeat2,
  Boxes,
  Bell,
  ScrollText,
  Settings,
} from 'lucide-react'

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/staff', label: 'Staff Registry', icon: Users },
  { to: '/job-descriptions', label: 'Job Descriptions', icon: FileText },
  { to: '/onboarding', label: 'Onboarding', icon: ClipboardCheck },
  { to: '/offboarding', label: 'Offboarding', icon: DoorOpen },
  { to: '/documents', label: 'Documents', icon: FolderLock },
  { to: '/access', label: 'Access Inventory', icon: KeyRound },
  { to: '/reassignments', label: 'Reassignments', icon: Repeat2 },
  { to: '/org-chart', label: 'Org Chart (3D)', icon: Boxes },
  { to: '/alerts', label: 'Alerts & Flags', icon: Bell },
  { to: '/audit-log', label: 'Audit Log', icon: ScrollText },
  { to: '/settings', label: 'Settings', icon: Settings },
]

export default function Sidebar() {
  return (
    <aside className="hidden lg:flex lg:flex-col w-64 shrink-0 bg-knosk-navy text-white/90 h-screen sticky top-0">
      <div className="flex items-center gap-2.5 px-6 h-20 border-b border-white/10">
        <div className="w-9 h-9 rounded-lg bg-knosk-gold flex items-center justify-center font-display font-extrabold text-knosk-navy text-lg">
          K
        </div>
        <div>
          <div className="font-display font-bold text-white leading-tight">KNOSK</div>
          <div className="text-[11px] tracking-wide text-white/50 leading-tight">HR SYSTEM</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto scrollbar-thin py-4 px-3 space-y-0.5">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              [
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-knosk-gold text-knosk-navy'
                  : 'text-white/70 hover:bg-knosk-navy-2 hover:text-white',
              ].join(' ')
            }
          >
            <Icon size={17} strokeWidth={2.2} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="px-4 py-4 border-t border-white/10 text-[11px] text-white/40">
        KNOSK Charity Education Initiative
        <br />
        &amp; N100-A-Day Charity Secondary School
      </div>
    </aside>
  )
}
