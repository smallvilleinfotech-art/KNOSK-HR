import { useMemo } from 'react'
import { Line } from '@react-three/drei'

export default function Edge3D({ from, to, isDimmed }) {
  const points = useMemo(
    () => [
      [from.x, from.y, from.z],
      [to.x, to.y, to.z],
    ],
    [from, to]
  )
  return (
    <Line
      points={points}
      color="#5b6478"
      lineWidth={1.2}
      transparent
      opacity={isDimmed ? 0.15 : 0.55}
    />
  )
}
