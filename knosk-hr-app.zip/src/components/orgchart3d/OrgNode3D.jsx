import { Html } from '@react-three/drei'

const TYPE_COLOR = {
  board: '#0b2545',
  leadership: '#1f5fbf',
  department: '#f2a71b',
  unit: '#5b93e6',
  role: '#5b6478',
}

export default function OrgNode3D({ node, isSelected, isDimmed, onSelect }) {
  const color = TYPE_COLOR[node.node_type] ?? '#5b6478'
  const size = node.node_type === 'board' ? 0.34 : node.node_type === 'leadership' ? 0.28 : 0.22

  return (
    <group position={[node.x, node.y, node.z]}>
      <mesh
        onClick={(e) => {
          e.stopPropagation()
          onSelect(node)
        }}
        scale={isSelected ? 1.35 : 1}
      >
        <sphereGeometry args={[size, 24, 24]} />
        <meshStandardMaterial
          color={color}
          emissive={isSelected ? color : '#000000'}
          emissiveIntensity={isSelected ? 0.6 : 0}
          transparent
          opacity={isDimmed ? 0.25 : 1}
        />
      </mesh>

      <Html
        center
        distanceFactor={9}
        style={{ pointerEvents: 'none', opacity: isDimmed ? 0.35 : 1, transition: 'opacity 200ms' }}
        occlude={false}
      >
        <div
          className={`px-2.5 py-1.5 rounded-lg text-center whitespace-nowrap shadow-sm border ${
            isSelected ? 'bg-knosk-navy text-white border-knosk-navy' : 'bg-white/95 text-knosk-navy border-knosk-line'
          }`}
          style={{ transform: 'translateY(-28px)', minWidth: 90 }}
        >
          <div className="text-[11px] font-display font-bold leading-tight">{node.title}</div>
          {node.current_holder && (
            <div className={`text-[10px] leading-tight ${isSelected ? 'text-white/70' : 'text-knosk-slate'}`}>
              {node.current_holder}
            </div>
          )}
        </div>
      </Html>
    </group>
  )
}
