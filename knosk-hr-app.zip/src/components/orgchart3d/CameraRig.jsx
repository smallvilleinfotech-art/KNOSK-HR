import { useRef, useEffect } from 'react'
import { useFrame } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import * as THREE from 'three'

export default function CameraRig({ focusPoint }) {
  const controlsRef = useRef(null)
  const targetVec = useRef(new THREE.Vector3(0, -1.5, 0))
  const desiredTarget = useRef(new THREE.Vector3(0, -1.5, 0))

  useEffect(() => {
    if (focusPoint) {
      desiredTarget.current.set(focusPoint.x, focusPoint.y, focusPoint.z)
    }
  }, [focusPoint])

  useFrame(() => {
    if (!controlsRef.current) return
    targetVec.current.lerp(desiredTarget.current, 0.08)
    controlsRef.current.target.copy(targetVec.current)
    controlsRef.current.update()
  })

  return (
    <OrbitControls
      ref={controlsRef}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      minDistance={2.5}
      maxDistance={20}
      maxPolarAngle={Math.PI * 0.9}
    />
  )
}
