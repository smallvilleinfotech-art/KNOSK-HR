import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function ProtectedRoute({ children }) {
  const { session, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-knosk-cream text-knosk-slate text-sm">
        Loading KNOSK HR…
      </div>
    )
  }

  if (!session) return <Navigate to="/login" replace />

  return children
}
