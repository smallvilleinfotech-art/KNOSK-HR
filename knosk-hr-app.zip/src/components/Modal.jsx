import { X } from 'lucide-react'

export default function Modal({ title, onClose, children, wide = false }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-knosk-navy/40 backdrop-blur-sm">
      <div className={`w-full ${wide ? 'max-w-2xl' : 'max-w-md'} bg-white rounded-card shadow-xl max-h-[90vh] overflow-y-auto scrollbar-thin`}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-knosk-line sticky top-0 bg-white">
          <h3 className="font-display font-bold text-knosk-navy">{title}</h3>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-knosk-blue-50 text-knosk-slate">
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}
