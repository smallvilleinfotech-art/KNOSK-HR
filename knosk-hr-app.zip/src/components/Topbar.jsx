import { Search, Bell, ChevronDown, LogOut } from 'lucide-react'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Topbar({ title, subtitle }) {
  const { profile, signOut } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)

  const initials = (profile?.full_name || profile?.email || '?')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  return (
    <header className="sticky top-0 z-10 flex items-center justify-between gap-4 h-20 px-6 lg:px-8 bg-knosk-cream/90 backdrop-blur border-b border-knosk-line">
      <div>
        <h1 className="font-display text-xl font-bold text-knosk-navy">{title}</h1>
        {subtitle && <p className="text-sm text-knosk-slate mt-0.5">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-2 bg-white border border-knosk-line rounded-full px-3.5 py-2 w-64">
          <Search size={16} className="text-knosk-slate" />
          <input
            placeholder="Search staff, roles, docs..."
            className="bg-transparent text-sm outline-none w-full placeholder:text-knosk-slate/70"
          />
        </div>

        <button
          className="relative w-10 h-10 rounded-full bg-white border border-knosk-line flex items-center justify-center hover:border-knosk-blue transition-colors"
          aria-label="Alerts"
        >
          <Bell size={17} className="text-knosk-navy" />
          <span className="absolute top-2 right-2.5 w-1.5 h-1.5 rounded-full bg-knosk-gold" />
        </button>

        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-full border border-knosk-line bg-white hover:border-knosk-blue transition-colors"
          >
            <span className="w-8 h-8 rounded-full bg-knosk-blue text-white text-xs font-semibold flex items-center justify-center">
              {initials}
            </span>
            <span className="hidden md:block text-sm font-medium text-knosk-navy max-w-[8rem] truncate">
              {profile?.full_name || profile?.email || 'Account'}
            </span>
            <ChevronDown size={14} className="text-knosk-slate" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white border border-knosk-line rounded-xl shadow-lg py-1.5 overflow-hidden">
              <div className="px-3.5 py-2 text-xs text-knosk-slate border-b border-knosk-line">
                {profile?.role?.replaceAll('_', ' ') || 'staff viewer'}
              </div>
              <button
                onClick={signOut}
                className="w-full flex items-center gap-2 px-3.5 py-2 text-sm text-knosk-ink hover:bg-knosk-blue-50"
              >
                <LogOut size={15} /> Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
