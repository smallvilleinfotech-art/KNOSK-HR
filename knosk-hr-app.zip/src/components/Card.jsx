export function Card({ className = '', children }) {
  return (
    <div className={`bg-white border border-knosk-line rounded-card ${className}`}>
      {children}
    </div>
  )
}

export function StatCard({ label, value, delta, accent = 'blue' }) {
  const accents = {
    blue: 'text-knosk-blue',
    gold: 'text-knosk-gold',
    navy: 'text-knosk-navy',
  }
  return (
    <Card className="p-5">
      <div className="text-3xl font-display font-extrabold text-knosk-navy">{value}</div>
      <div className="text-sm text-knosk-slate mt-1">{label}</div>
      {delta && <div className={`text-xs font-medium mt-2 ${accents[accent]}`}>{delta}</div>}
    </Card>
  )
}
