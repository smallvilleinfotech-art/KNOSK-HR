export function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-knosk-slate mb-1.5">{label}</label>
      {children}
    </div>
  )
}

export const inputCls =
  'w-full border border-knosk-line rounded-lg px-3.5 py-2.5 text-sm outline-none focus:border-knosk-blue focus:ring-2 focus:ring-knosk-blue-50 bg-white'

export const buttonPrimary =
  'bg-knosk-blue text-white rounded-lg px-4 py-2.5 text-sm font-semibold hover:bg-knosk-blue/90 disabled:opacity-60 transition-colors'

export const buttonGhost =
  'border border-knosk-line text-knosk-ink rounded-lg px-4 py-2.5 text-sm font-semibold hover:border-knosk-blue transition-colors'
