import { Outlet, useMatches } from 'react-router-dom'
import Sidebar from '../components/Sidebar'
import Topbar from '../components/Topbar'

export default function AppShell() {
  const matches = useMatches()
  const current = [...matches].reverse().find((m) => m.handle?.title)
  const title = current?.handle?.title ?? 'Dashboard'
  const subtitle = current?.handle?.subtitle

  return (
    <div className="flex min-h-screen bg-knosk-cream">
      <Sidebar />
      <div className="flex-1 min-w-0">
        <Topbar title={title} subtitle={subtitle} />
        <main className="p-6 lg:p-8 max-w-[1400px]">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
